// CREATED BY RYKER WELLNITZ
// CIS150AB FINAL PROJECT
// 5/8/2023
// Small text-based fighting game, survive as long as you can.

public class Enemy extends Character {
	
	// Enemy type can be either orc or wizard ( 0 is orc, 1 is wizard)
	int enemyType;
	int statRange = 6;
	
	// Sets up enemy based on class
	public Enemy() {
		// 'randomly' selects enemy class
		enemyType = randomNum(1);
		attackRange = 4;
		
		// This if else block will make the enemy "classes" different
		// If enemy is an orc
		if (enemyType == 0) {
			// Raises health / lowers mana but up to 5 points
			health += randomNum(statRange);
			mana -= randomNum(statRange);
			name = "Orc";
		}
		// If enemy is a wizard
		else {		
			// Lowers health / raises mana but up to 5 points
			health -= randomNum(statRange);
			mana += randomNum(statRange);
			name = "Wizard";
		}
	}
	
	// This method allows the enemy to take its turn
	public void takeTurn (Character player) {
		
		// Checks conditions to use mana, else has user attack
		if ((randomNum(10) > 6) && (mana >=2)) {
			useMana();
		}
		else {
			useAttack(player);
		}
	}
}
