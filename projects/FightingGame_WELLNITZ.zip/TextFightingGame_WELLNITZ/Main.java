// CREATED BY RYKER WELLNITZ
// CIS150AB FINAL PROJECT
// 5/8/2023
// Small text-based fighting game, survive as long as you can.

import java.util.InputMismatchException;
import java.util.Scanner;

// This class is for handling the main game loop
public class Main {
	// Variables needed everywhere
	static Scanner scnr = new Scanner(System.in);
	static Character player = new Character();
	static Enemy enemy;
	static boolean playing = true;
	static boolean enemyAlive;
	static int enemiesDefeated = 0;
		
	public static void main(String[] args) {
		System.out.println("\n----------CIS150\n---FINAL PROJECT");
		System.out.println("--RYKER WELLNITZ\n");
		
		System.out.print("Enter player name: ");
		player.setName(getString());
		
		enterToContinue();
		
		// This loop keeps spawning enemies until the player quits or loses
		while (playing == true) {
			enemy = new Enemy();
			enemyAlive = true;
			System.out.println("-=========- NEW ROUND -=========-");
			System.out.println("\nA " + enemy.getName() + " approaches!");
			
			// Everything in this loop is one "round"
			while (enemyAlive == true && playing == true) {
				drawSetup();
				
				fight();
				
				enterToContinue();
				
				// If player has been defeated then end game
				if (player.getHealth() <= 0) {
					playing = false;
					System.out.println("-=========- ROUND LOST -=========-");
					System.out.println(player.getName() + " has been defeated!");
					System.out.println("Better luck next time!");
					
				}
			}
		}
		
		// Shows player stats and goodbye message
		onEnd();
	}
	
	//This method handles anything related to the fighting part of a round
	public static void fight() {
		int option = getInt(2);
		
		// Switch statement to handle which action to do
		switch (option) {
			case 1:
				// Handles attacking
				player.useAttack(enemy);
				break;
			case 2:
				// Handles mana
				if (player.getMana() >= 2) {
					player.useMana();
				} else {
					System.out.println(player.getName() + " has no mana!");
					return;
				}
				break;
			case 0:
				// Quits game
				playing = false;
				return;
		}
		
		// Checks if enemy has been defeated. if yes, skips their turn to start a new round
			if (enemy.getHealth() <= 0) {
				System.out.println("-=========- ROUND WON -=========-");
				System.out.println("\n" + player.getName() + " defeated " + enemy.getName() + "!");
				enemyAlive = false;
				enemiesDefeated += 1;
				return;
			} else {
				enemy.takeTurn(player);
			}
	}
	
	// This method is for after the game ends
	public static void onEnd() {
		System.out.println("-=======================-");
		System.out.println("Thanks for playing!");
		System.out.println(player.getName() + " defeated " + enemiesDefeated + " enemy(s)!");
		
	}
	
	// This method lets me stop the console until the user presses enter
	public static void enterToContinue() {
		System.out.print("\nPress Enter to continue");
		try {
			System.in.read();
		} catch(Exception e){}
	}
	
	// This method gets input and validates its an int
	public static int getInt(int max) {
		// While loop to keep getting input until it is valid
		while (true) {
			//Tries to get input
			try {
				int input = scnr.nextInt();
				
				// Makes sure number is in bounds
				if ((input > max) || (input < 0)) {
					throw new InputMismatchException();
				}
				
				return input;
			} catch (InputMismatchException excpt) {
				// Restarts getting input
				System.out.println("Invalid input, try again!");
				scnr.nextLine();
			}
		}
	}
	
	// This method gets input and validates its a string
	public static String getString() {
		// While loop to keep getting input until it is valid
		while (true) {
			try {
				String input = scnr.nextLine();
				
				//Stops user from inputting blank username (you could technically use spaces, but it doesnt really matter)
				if (input == "") {
					throw new InputMismatchException();
				}
				
				return input;
			
			} catch (InputMismatchException excpt) {
				System.out.println("Invalid input, try again!");
				scnr.nextLine();
			}
		}
	}
	
	// This method will "draw" the setup screen each round
	public static void drawSetup() {
		System.out.println("\n---------- " + player.getName() + " ----------");
		System.out.println("  " + player.getHealth() + " health | " + player.getMana() + " mana");
		System.out.println("---------- " + enemy.getName() + " ----------");
		System.out.println("  " + enemy.getHealth() + " health | " + enemy.getMana() + " mana");
		System.out.println("-=======================-");
		System.out.println("    1 Key)---ATTACK");
		System.out.println("    2 Key)----MAGIC");
		System.out.println("    0 Key)QUIT-GAME");
		System.out.println("-=======================-");
	}
}
