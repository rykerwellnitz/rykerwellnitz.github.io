// CREATED BY RYKER WELLNITZ
// CIS150AB FINAL PROJECT
// 5/8/2023
// Small text-based fighting game, survive as long as you can.

public class Character {
	
	// Variables
	protected int health;
	protected int mana;
	protected String name;
	
	// Max attack damage
	protected int attackRange = 6;
	
	// Basic constructor
	public Character() {
		health = 10;
		mana = 10;
		name = "User";
	}
	
	// This method will "Attack" an enemy player
	public void useAttack (Character subject) {
		int damage = randomNum(attackRange);
		
		subject.setHealth(subject.getHealth() - damage);
		
		System.out.println("\n" + name + " attacked " + subject.getName() + " for " + damage + " damage!");
	}
	
	// This method will use mana to heal player
	public void useMana () {
		// Subtracts mana and adds health
		mana -= 2;
		health += 2;
		
		System.out.println("\n" + name + " healed for 2 health!");
	}
	
	// Method for random integer
	public int randomNum (int range) {
		return (int)Math.floor(Math.random() * (range + 1));
	}
	
	// A bunch of get/set methods
	public void setHealth (int healthVal) {
		this.health = healthVal;
	}
		
	public int getHealth () {
		return this.health;
	}
		
	public void setMana (int manaVal) {
		this.mana = manaVal;
	}
		
	public int getMana () {
		return this.mana;
	}
		
	public void setName (String nameVal) {
		this.name = nameVal;
	}
		
	public String getName () {
		return this.name;
	}
}
